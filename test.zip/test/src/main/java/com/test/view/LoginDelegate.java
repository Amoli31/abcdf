/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.test.view;

import com.test.dao.UserDao;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author amoli.barbhaya
 */
public class LoginDelegate 
{
   
    private UserDao userDao;

    public UserDao getUserDao() {
        return this.userDao;
    }

    public void setUserDao(UserDao userDao) {
        this.userDao = userDao;
    }

    public boolean isValidUser(String Username, String Password)  {
        //        return (username.equals("amoli"));
        boolean validUser;
        try {
            validUser = userDao.isValidUser(Username, Password);
            return validUser;
        } catch (SQLException ex) {
            Logger.getLogger(LoginDelegate.class.getName()).log(Level.SEVERE, null, ex);
        return false;
        }
       
    }
}


