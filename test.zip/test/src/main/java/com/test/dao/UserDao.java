package com.test.dao;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.sql.SQLException;

/**
 *
 * @author amoli.barbhaya
 */
public interface UserDao  {
      
    public boolean isValidUser(String Username, String Password) throws SQLException;
//     {
//         //userDao.isValidUser(Username,Password);
//     }
//
//    return userDao.isValidUser(Username, Password);
}
